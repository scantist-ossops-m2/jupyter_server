c.SimpleApp11.ignore_js = True
