.. _user-getting-help:

Getting Help
============

If you run into any issues or bugs, please open an `issue on Github <https://github.com/jupyter/jupyter_server/issues>`_.

We'd also love to have you come by our :ref:`Team Meetings <contributors-team-meetings-roadmap-calendar>`.