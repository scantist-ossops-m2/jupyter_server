c.SimpleApp2.configD = 'ConfigD from file'
