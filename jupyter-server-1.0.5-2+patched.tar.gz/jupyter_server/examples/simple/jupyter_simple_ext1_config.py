c.SimpleApp1.configA = 'ConfigA from file'
c.SimpleApp1.configB = 'ConfigB from file'
c.SimpleApp1.configC = 'ConfigC from file'
c.SimpleApp1.configD = 'ConfigD from file'
