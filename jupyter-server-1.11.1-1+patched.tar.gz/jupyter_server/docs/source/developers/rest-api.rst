The REST API
============

An interactive version is available
`here <https://petstore.swagger.io/?url=https://raw.githubusercontent.com/jupyter/jupyter_server/master/jupyter_server/services/api/api.yaml>`_.

.. openapi:: ../../../jupyter_server/services/api/api.yaml
